function [EG,EN]=xunhuan1(t,Pmnet,EG,EN,PN,PB,PG,ac_ess,E_ess,ac_lvvb,E_LVVBj)
%  xunhuan1����Ϊ
        EG(:,t)=[704;
        550;600;680;875;
        0;0;0;0;0;
        300;350;400;%EGess0=[300 350 400];%������ʼ̼��
        0;0;0;0;0;0;
        500;490;434;460;%EGlvvb0=[550;490;434;460];LVVB��ʼ̼��
        ];
    if Pmnet(1,t)>0
        EG(1,t)=704;
    else
        EG(1,t)=0;
    end
    for e=1:3
       if ac_ess(e,2)<=0
           EG(10+e,t)=EG(10+e,t-1);
       else
           EG(10+e,t)=(EG(10+e,t-1)*E_ess(e,t-1)+EN(ac_ess(e,1),t)*1000*ac_ess(e,2))/(E_ess(e,t-1)+1000*ac_ess(e,2));
       end
   end
   for k=1:4
       if ac_lvvb(k,2)<=0
           EG(19+k,t)=EG(19+k,t-1);
       else
           EG(19+k,t)=(EG(19+k,t-1)*E_LVVBj(k,t-1)+EN(ac_lvvb(k,1),t)*1000*ac_lvvb(k,2))/(E_LVVBj(k,t-1)+1000*ac_lvvb(k,2));
       end
   end
%�ڵ�̼�Ʒֲ�����
EN(:,t+1)=(PN-PB')^(-1)*PG'*EG(:,t);%���ﲻ��Ҫ��λ��ת����(MW^-1)*MW*gCO2/kWh
% disp('�ڵ�̼�Ʒֲ�������')
% disp(EN)

