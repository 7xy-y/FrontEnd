function [EG,EN]=xunhuan2(t,Pmnet,EG,EN,PN,PB,PG,ac_ess,E_ess,ac_ess_T,ac_lvvb,E_LVVBj,ac_lvvb_T)
 %xunhuan2�ĺ���Ϊ
    for e=1:3
       if ac_ess_T(e,t-1)<=0
           EG(10+e,t-1)=EG(10+e,t-1);
       else
           EG(10+e,t-1)=(EG(10+e,t-1)*E_ess(e,t-1)+EN(ac_ess(e,1),t)*1000*ac_ess_T(e,t-1))/(E_ess(e,t-1)+1000*ac_ess_T(e,t-1));
       end
    end
   for k=1:4
       if ac_lvvb_T(k,t-1)<=0
           EG(19+k,t-1)=EG(19+k,t-1);
       else
           EG(19+k,t-1)=(EG(19+k,t-1)*E_LVVBj(k,t-1)+EN(ac_lvvb(k,1),t)*1000*ac_lvvb_T(k,t-1))/(E_LVVBj(k,t-1)+1000*ac_lvvb_T(k,t-1));
       end
   end
%�ڵ�̼�Ʒֲ�����
EN(:,t+1)=(PN-PB')^(-1)*PG'*EG(:,t-1);%���ﲻ��Ҫ��λ��ת����(MW^-1)*MW*gCO2/kWh
% disp('�ڵ�̼�Ʒֲ�������')
% disp(EN)
